<?php

namespace App\Controllers;

use App\Models\ProductModel;

class Product extends BaseController
{
    protected $product;

    public function __construct()
    {
        $this->product = new ProductModel();
    }

    public function index()
    {
        $keyword = $this->request->getGet('q');

        if ($keyword) {
            $products = $this->product
                ->like('name', $keyword)
                ->orLike('description', $keyword)
                ->findAll();
        } else {
            $products = $this->product->findAll();
        }

        return view('product/index', [
            'products' => $products,
            'keyword'  => $keyword
        ]);
    }

    public function store()
    {
        $this->product->insert([
            'name' => $this->request->getPost('name'),
            'price' => $this->request->getPost('price'),
            'stock' => $this->request->getPost('stock'),
            'description' => $this->request->getPost('description'),
        ]);

        return redirect()->to('/product');
    }

    public function update($id)
    {
        $this->product->update($id, [
            'name' => $this->request->getPost('name'),
            'price' => $this->request->getPost('price'),
            'stock' => $this->request->getPost('stock'),
            'description' => $this->request->getPost('description'),
        ]);

        return redirect()->to('/product');
    }

    public function delete($id)
    {
        $this->product->delete($id);
        return redirect()->to('/product');
    }
}
