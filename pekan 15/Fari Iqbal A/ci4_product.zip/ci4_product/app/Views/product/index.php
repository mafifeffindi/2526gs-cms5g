<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Product Management</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="/css/product.css">
</head>
<body>

<div class="container py-5">

    <h4 class="mb-4 fw-semibold">Product Management</h4>

    <div class="row g-4">

        <!-- FORM INPUT -->
        <div class="col-md-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h6 class="text-muted mb-3">Add Product</h6>

                    <form method="post" action="/product/store">
                        <input class="form-control mb-2" name="name" placeholder="Product Name" required>
                        <input class="form-control mb-2" name="price" placeholder="Price" required>
                        <input class="form-control mb-2" name="stock" placeholder="Stock" required>
                        <textarea class="form-control mb-3" name="description" placeholder="Description"></textarea>
                        <button class="btn btn-primary w-100">Save</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- DATA -->
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-body">

                    <!-- SEARCH -->
                    <form method="get" action="/product" class="mb-3">
                        <div class="input-group">
                            <input type="text" name="q" value="<?= esc($keyword ?? '') ?>"
                                   class="form-control" placeholder="Search product...">
                            <button class="btn btn-outline-secondary">Search</button>
                        </div>
                    </form>

                    <table class="table table-bordered align-middle">
                        <thead class="table-light">
                        <tr>
                            <th>Name</th>
                            <th width="100">Price</th>
                            <th width="80">Stock</th>
                            <th>Description</th>
                            <th width="170">Action</th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php if ($products): ?>
                            <?php foreach ($products as $p): ?>
                                <tr>
                                    <td>
                                        <form method="post" action="/product/update/<?= $p['id'] ?>" class="row g-2">
                                            <input type="text" name="name" value="<?= esc($p['name']) ?>" class="form-control">
                                    </td>
                                    <td>
                                            <input type="number" name="price" value="<?= esc($p['price']) ?>" class="form-control">
                                    </td>
                                    <td>
                                            <input type="number" name="stock" value="<?= esc($p['stock']) ?>" class="form-control">
                                    </td>
                                    <td>
                                            <input type="text" name="description" value="<?= esc($p['description']) ?>" class="form-control">
                                    </td>
                                    <td class="text-center">
                                            <button class="btn btn-success btn-sm mb-1">Update</button>
                                            <a href="/product/delete/<?= $p['id'] ?>"
                                               onclick="return confirm('Delete this product?')"
                                               class="btn btn-danger btn-sm">
                                                Delete
                                            </a>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted">
                                    No data available
                                </td>
                            </tr>
                        <?php endif ?>

                        </tbody>
                    </table>

                </div>
            </div>
        </div>

    </div>
</div>

</body>
</html>
